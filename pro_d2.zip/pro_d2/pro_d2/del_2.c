#define _CRT_SECURE_NO_WARNINGS 
#if defined(_MSC_VER)
#if ndefn CRT SECURE_NO_DEPRECAT
#define CRT SECURE_NO_DEPRECAT (1)
#endif
#pragma warning(disable : 4996)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct
{
	char name[10];
	char lname[10];
	int ssn;
	int id;
	char pos[15];
	int salary;
}EmployeeInformationTable;
typedef struct
{
	char name[10];
	char lname[10];
	int id;
	char city[10];
	char state[5];
	int b;
}EmployeeAddressTable;
typedef struct
{
	char name[10];
	char lname[10];
	int id;
	int salary;
	int bon;
	char pos[15];

}EmployeeBenefitstable;
typedef struct
{
	int id;
	int salary;
	int ben;
	char pos[15];
}EmployeeStatisticsTable;
typedef struct
{
	char select[60];
	char from[60];
	char wher[60];

}QWR;

typedef struct EIE
{
	int FirstName;
	int LastName;
	int SSN;
	int ID;
	int Position;
	int Salary;
}EIE;
typedef struct EAE
{
	int FirstName;
	int LastName;
	int ID;
	int City;
	int State;
	int Bldg;
}EAE;
typedef struct EBE
{
	int FirstName;
	int LastName;
	int ID;
	int Salary;
	int Bonus;
	int Position;
}EBE;
typedef struct ESE
{
	int EmployeeIDNo;
	int Salary;
	int Benefits;
	int Position;
}ESE;



void load_table(EmployeeInformationTable* t1, EmployeeAddressTable* t2, EmployeeBenefitstable* t3, EmployeeStatisticsTable* t4, FILE* t);
void load_query_files(FILE* q, /*char qs[15][100],*/ QWR* qw);
void load_tables(EmployeeInformationTable* t1, EmployeeAddressTable* t2, EmployeeBenefitstable* t3, EmployeeStatisticsTable* t4, FILE* t);
void load_query_file(FILE* q, /*char qs[15][100],*/ QWR* qw);
void checkselect();
int checkquerys();
void findcon();
int findrows(int row_check);
int lookingCondition2 = 0;
char lookingColumn2[999];
char lookingColumnValue2[999];
char lookingLikeChar;

int  functionFlag = 0;
char functionName[999];
char functionColumn[999];

long sum = 0;
float avg = 0;
int avg_counter;
long max = -10000000;
long min = 10000000;
char* qs[15][100];
int counter = 0;
EIE EIEd;
EAE EAEd;
EBE EBEd;
ESE ESEd;

int selection = 0;
int rows = 0;
char * Results; 
char * pch;
int  QueryFlag = 1;
int  TablesFlag = 1;

char current[999];
char currentSegment[20][999];
int  currentSegmentCounter = 0;

int currenttable = 0;

int  lookingFlag = 0;
int  lookingCondition = 0;

char lookingColumn[999];
char lookingColumnValue[999];
char lookingLink[999];

int main()
{
	int i, r = 1, n, c, j;
	FILE* t;
	FILE* q;
	char qq[15][100];
	FILE* fp;
	EmployeeInformationTable* t1;
	EmployeeAddressTable* t2;
	EmployeeBenefitstable* t3;
	EmployeeStatisticsTable* t4;
	QWR* qw;
	t = fopen("appendixA.txt", "r");
	q = fopen("appendixB.txt", "r");
	if (t == NULL || q == NULL)
	{
		printf("files are not found\n\n\n");
		r = 0;

	}
	else
	{
		fclose(t);
		fclose(q);
		q = fopen("appendixB.txt", "r");
		while (fgets(qq, 100, q))
			selection++;
		fclose(q);
		t1 = (EmployeeInformationTable*)calloc(5, sizeof(EmployeeInformationTable));
		t2 = (EmployeeAddressTable*)calloc(5, sizeof(EmployeeAddressTable));
		t3 = (EmployeeBenefitstable*)calloc(5, sizeof(EmployeeBenefitstable));
		t4 = (EmployeeStatisticsTable*)calloc(9, sizeof(EmployeeStatisticsTable));
		qw = (QWR*)calloc(selection, sizeof(QWR));









		while (r)
		{
			do{
				system("cls");
				printf(" 1) Load Tables file\n 2)Load Queries file \n 3)Execute and Display to Screen \n 4)Execute and Store to File \n 5)Exit \n");
				scanf("%d", &c);
				if (c > 5)
				{
					printf("Error/n/n");
					system("pause");
				}
			} while (c > 5);

			switch (c)
			{
			case 1:
			{
				t = fopen("appendixA.txt", "r");
				load_tables(t1, t2, t3, t4, t);
				fclose(t);
				break;
			}
			case 2:
			{
				q = fopen("appendixB.txt", "r");
				load_query_file(q, qs, qw);
				fclose(q);
				break;
			}
			case 3:
			case 4:
			{
				t = fopen("appendixA.txt", "r");
				load_table(t1, t2, t3, t4, t);
				fclose(t);
				q = fopen("appendixB.txt", "r");
				load_query_files(q, qs, qw);
				fclose(q);
				fp = fopen("file.txt", "w");
				if (checkquerys() == 1)
				{
					for (j = 0; j < selection; j++){
						strcpy(current, qs[j]);
						printf("\n%s\n", current);
						if (c == 4)
							fprintf(fp, "\n%s\n", current);

						for (i = 0; i < 8; i++){
							strcpy(currentSegment[i], "");
						}

						i = 0;
						pch = strtok(current, " ");
						while (pch != NULL)
						{
							strcpy(currentSegment[i], pch);
							i++;
							pch = strtok(NULL, " ");
						}
						checkselect();
						findcon();
						if (currenttable == 1){
							for (i = 0; i <= 4; i++)
							{
								if (findrows(i, t1, t2, t3, t4) == 1)
								{

									if (functionFlag == 1)
									{
										if (strcmpi(functionName, "SUM") == 0)
											sum += t1[i].salary;
										else if (strcmpi(functionName, "AVG") == 0)
										{
											sum += t1[i].salary;
											avg_counter++;
										}
										else if (strcmpi(functionName, "MAX") == 0)
										{
											if (max < t1[i].salary){
												max = t1[i].salary;
											}
										}
										else if (strcmpi(functionName, "MIN") == 0)
											if (min > t1[i].salary)
												min = t1[i].salary;
											else if (strcmpi(functionName, "COUNT") == 0)
												avg_counter++;

									}
									else
									{

										if (EIEd.FirstName == 1) printf("%s \t", t1[i].name);
										if (EIEd.LastName == 1) printf("%s \t", t1[i].lname);
										if (EIEd.SSN == 1) printf("%d \t", t1[i].ssn);
										if (EIEd.ID == 1) printf("%d \t", t1[i].id);
										if (EIEd.Position == 1) printf("%s \t", t1[i].pos);
										if (EIEd.Salary == 1) printf("%d \t", t1[i].salary);
										printf("\n");
										if (c == 4){
											if (EIEd.FirstName == 1) fprintf(fp, "%s \t", t1[i].name);
											if (EIEd.LastName == 1) fprintf(fp, "%s \t", t1[i].lname);
											if (EIEd.SSN == 1) fprintf(fp, "%d \t", t1[i].ssn);
											if (EIEd.ID == 1) fprintf(fp, "%d \t", t1[i].id);
											if (EIEd.Position == 1) fprintf(fp, "%s \t", t1[i].pos);
											if (EIEd.Salary == 1) fprintf(fp, "%d \t", t1[i].salary);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "SUM") == 0)
							{
								if (c == 4)
									fprintf(fp, "\n%d\n", sum);
								printf("\n%d\n", sum);
								sum = 0;
							}
							if (strcmpi(functionName, "AVG") == 0)
							{
								avg = sum / avg_counter;
								printf("\n%1.2f\n", avg);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg);
								sum = 0;
								avg_counter = 0;
							}
							if (strcmpi(functionName, "MAX") == 0)
							{
								printf("\n%d\n", max);
								if (c == 4)
									fprintf(fp, "\n%d\n", max);
								max = -10000000;
							}
							if (strcmpi(functionName, "MIN") == 0)
							{
								printf("\n%d\n", min);
								if (c == 4) fprintf(fp, "\n%d\n", min);
								min = 10000000;
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}
						if (currenttable == 2)
						{
							for (i = 0; i <= 4; i++)
							{
								if (findrows(i, t1, t2, t3, t4) == 1)
								{
									if (functionFlag == 1)
									{
										if (strcmpi(functionName, "COUNT") == 0)
											avg_counter++;

									}
									else
									{

										if (EAEd.FirstName == 1)
											printf("%s \t", t2[i].name);
										if (EAEd.LastName == 1)
											printf("%s \t", t2[i].lname);
										if (EAEd.ID == 1)
											printf("%d \t", t2[i].id);
										if (EAEd.City == 1)
											printf("%s \t", t2[i].city);
										if (EAEd.State == 1)
											printf("%s \t", t2[i].state);
										if (EAEd.Bldg == 1)
											printf("%d \t", t2[i].b);
										printf("\n");
										if (c == 4){
											if (EAEd.FirstName == 1)
												fprintf(fp, "%s \t", t2[i].name);
											if (EAEd.LastName == 1)
												fprintf(fp, "%s \t", t2[i].lname);
											if (EAEd.ID == 1)
												fprintf(fp, "%d \t", t2[i].id);
											if (EAEd.City == 1)
												fprintf(fp, "%s \t", t2[i].city);
											if (EAEd.State == 1)
												fprintf(fp, "%s \t", t2[i].state);
											if (EAEd.Bldg == 1)
												fprintf(fp, "%d \t", t2[i].b);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}
						if (currenttable == 3)
						{
							for (i = 0; i <= 4; i++)
							{
								if (findrows(i, t1, t2, t3, t4) == 1)
								{

									if (functionFlag == 1)
									{

										if (strcmpi(functionName, "SUM") == 0)
										{

											if (EBEd.Salary == 1)
												sum += t3[i].salary;
											if (EBEd.Bonus == 1)
												sum += t3[i].bon;

										}
										else if (strcmpi(functionName, "AVG") == 0)
										{
											if (EBEd.Salary == 1)
												sum += t3[i].salary;
											if (EBEd.Bonus == 1)
												sum += t3[i].bon;
											avg_counter++;
										}
										else if (strcmpi(functionName, "MAX") == 0)
										{
											if (EBEd.Salary == 1)
												if (max < t3[i].salary)
													max = t3[i].salary;
											if (EBEd.Bonus == 1)
												if (max < t3[i].bon)
													max = t3[i].bon;

										}
										else if (strcmpi(functionName, "MIN") == 0)
										{
											if (EBEd.Salary == 1)
												if (min > t3[i].salary)
													min = t3[i].salary;
											if (EBEd.Bonus == 1)
												if (min > t3[i].bon)
													min = t3[i].bon;
										}
										else if (strcmpi(functionName, "COUNT") == 0)
											avg_counter++;
									}
									else
									{
										if (EBEd.FirstName == 1)
											printf("%s \t", t3[i].name);
										if (EBEd.LastName == 1)
											printf("%s \t", t3[i].lname);
										if (EBEd.ID == 1)
											printf("%d \t", t3[i].id);
										if (EBEd.Salary == 1)
											printf("%d \t", t3[i].salary);
										if (EBEd.Bonus == 1)
											printf("%d \t", t3[i].bon);
										if (EBEd.Position == 1)
											printf("%s \t", t3[i].pos);

										printf("\n");
										if (c == 4){
											if (EBEd.FirstName == 1)
												fprintf(fp, "%s \t", t3[i].name);
											if (EBEd.LastName == 1)
												fprintf(fp, "%s \t", t3[i].lname);
											if (EBEd.ID == 1)
												fprintf(fp, "%d \t", t3[i].id);
											if (EBEd.Salary == 1)
												fprintf(fp, "%d \t", t3[i].salary);
											if (EBEd.Bonus == 1)
												fprintf(fp, "%d \t", t3[i].bon);
											if (EBEd.Position == 1)
												fprintf(fp, "%s \t", t3[i].pos);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "SUM") == 0)
							{
								if (c == 4)
									fprintf(fp, "\n%d\n", sum);
								printf("\n%d\n", sum);
								sum = 0;
							}
							if (strcmpi(functionName, "AVG") == 0)
							{
								avg = sum / avg_counter;
								printf("\n%1.2f\n", avg);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg);
								sum = 0;
								avg_counter = 0;
							}
							if (strcmpi(functionName, "MAX") == 0)
							{
								printf("\n%d\n", max);
								if (c == 4)
									fprintf(fp, "\n%d\n", max);
								max = -10000000;
							}
							if (strcmpi(functionName, "MIN") == 0)
							{
								printf("\n%d\n", min);
								if (c == 4)
									fprintf(fp, "\n%d\n", min);
								min = 10000000;
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}

						if (currenttable == 4)
						{
							for (i = 0; i <= 8; i++)
							{
								if (findrows(i, t1, t2, t3, t4) == 1)
								{

									if (functionFlag == 1)
									{

										if (strcmpi(functionName, "SUM") == 0)
										{

											if (ESEd.Salary == 1)
												sum += t4[i].salary;
											if (ESEd.Benefits == 1)
												sum += t4[i].ben;

										}
										else if (strcmpi(functionName, "AVG") == 0)
										{
											if (ESEd.Salary == 1)
												sum += t4[i].salary;
											if (ESEd.Benefits == 1)
												sum += t4[i].ben;
											avg_counter++;
										}
										else if (strcmpi(functionName, "MAX") == 0)
										{
											if (ESEd.Salary == 1)
												if (max < t4[i].salary)
													max = t4[i].salary;
											if (ESEd.Benefits == 1)
												if (max < t4[i].ben)
													max = t4[i].ben;

										}
										else if (strcmpi(functionName, "MIN") == 0)
										{
											if (ESEd.Salary == 1)
												if (min > t4[i].salary)
													min = t4[i].salary;
											if (ESEd.Benefits == 1)
												if (min > t4[i].ben)
													min = t4[i].ben;
										}
										else if (strcmpi(functionName, "COUNT") == 0)
											avg_counter++;
									}
									else
									{
										if (ESEd.EmployeeIDNo == 1)
											printf("%d \t", t4[i].id);
										if (ESEd.Salary == 1)
											printf("%d \t", t4[i].salary);
										if (ESEd.Benefits == 1)
											printf("%d \t", t4[i].ben);
										if (ESEd.Position == 1)
											printf("%s \t", t4[i].pos);
										printf("\n");
										if (c == 4)
										{
											if (ESEd.EmployeeIDNo == 1)
												fprintf(fp, "%d \t", t4[i].id);
											if (ESEd.Salary == 1)
												fprintf(fp, "%d \t", t4[i].salary);
											if (ESEd.Benefits == 1)
												fprintf(fp, "%d \t", t4[i].ben);
											if (ESEd.Position == 1)
												fprintf(fp, "%s \t", t4[i].pos);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "SUM") == 0)
							{
								if (c == 4)
									fprintf(fp, "\n%d\n", sum);
								printf("\n%d\n", sum);
								sum = 0;
							}
							if (strcmpi(functionName, "AVG") == 0)
							{
								avg = sum / avg_counter;
								printf("\n%1.2f\n", avg);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg);
								sum = 0;
								avg_counter = 0;
							}
							if (strcmpi(functionName, "MAX") == 0)
							{
								printf("\n%d\n", max);
								if (c == c)
									fprintf(fp, "\n%d\n", max);
								max = -10000000;
							}
							if (strcmpi(functionName, "MIN") == 0)
							{
								printf("\n%d\n", min);
								if (c == 4)
									fprintf(fp, "\n%d\n", min);
								min = 10000000;
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}

					}
				}
				else
				{
					printf("Please load table and query first!\n");
				}
				system("pause");
				fclose(fp);
				break;
			case 5:
			{
				system("cls");
				r = 0;
				break;
			}
			system("pause");
			system("cls");
			}
			}
		}
		fclose(t);
		fclose(q);
		free(t1);
		free(t2);
		free(t3);
		free(t4);
		free(qw);
	}
	system("pause");
	return 0;
}

void load_tables(EmployeeInformationTable* t1, EmployeeAddressTable* t2, EmployeeBenefitstable* t3, EmployeeStatisticsTable* t4, FILE* t)
{
	int TablesFlag = 1;
	int x;
	int i;
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t1[i].name);
		fscanf(t, "%s ", t1[i].lname);
		fscanf(t, "%d ", &t1[i].ssn);
		fscanf(t, "%d ", &t1[i].id);
		fscanf(t, "%s ", t1[i].pos);
		fscanf(t, "%d ", &t1[i].salary);
	}
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t2[i].name);
		fscanf(t, "%s ", t2[i].lname);
		fscanf(t, "%d ", &t2[i].id);
		fscanf(t, "%s ", t2[i].city);
		fscanf(t, "%s ", t2[i].state);
		fscanf(t, "%d ", &t2[i].b);
	}
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t3[i].name);
		fscanf(t, "%s ", t3[i].lname);
		fscanf(t, "%d ", &t3[i].id);
		fscanf(t, "%d ", &t3[i].salary);
		fscanf(t, "%d ", &t3[i].bon);
		fscanf(t, "%s ", t3[i].pos);
	}
	for (i = 0; i < 9; i++)
	{
		fscanf(t, "%d ", &t4[i].id);
		fscanf(t, "%d ", &t4[i].salary);
		fscanf(t, "%d ", &t4[i].ben);
		fscanf(t, "%s ", t4[i].pos);
	}
	system("cls");
	printf("\nT1\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%d\t%s\t%d\n", t1[i].name, t1[i].lname, t1[i].ssn, t1[i].id, t1[i].pos, t1[i].salary);
	printf("\nT2\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%s\t%s\t%d\n", t2[i].name, t2[i].lname, t2[i].id, t2[i].city, t2[i].state, t2[i].b);
	printf("\nT3\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%d\t%d\t%s\n", t3[i].name, t3[i].lname, t3[i].id, t3[i].salary, t3[i].bon, t3[i].pos);
	printf("\nT4\n");
	for (i = 0; i < 9; i++)
		printf("%d\t%d\t%d\t%s\n", t4[i].id, t4[i].salary, t4[i].ben, t4[i].pos);
	printf("\n\n\n");

	system("pause");
	return;
}
void load_table(EmployeeInformationTable* t1, EmployeeAddressTable* t2, EmployeeBenefitstable* t3, EmployeeStatisticsTable* t4, FILE* t)
{
	int TablesFlag = 1;
	int x;
	int i;
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t1[i].name);
		fscanf(t, "%s ", t1[i].lname);
		fscanf(t, "%d ", &t1[i].ssn);
		fscanf(t, "%d ", &t1[i].id);
		fscanf(t, "%s ", t1[i].pos);
		fscanf(t, "%d ", &t1[i].salary);
	}
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t2[i].name);
		fscanf(t, "%s ", t2[i].lname);
		fscanf(t, "%d ", &t2[i].id);
		fscanf(t, "%s ", t2[i].city);
		fscanf(t, "%s ", t2[i].state);
		fscanf(t, "%d ", &t2[i].b);
	}
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t3[i].name);
		fscanf(t, "%s ", t3[i].lname);
		fscanf(t, "%d ", &t3[i].id);
		fscanf(t, "%d ", &t3[i].salary);
		fscanf(t, "%d ", &t3[i].bon);
		fscanf(t, "%s ", t3[i].pos);
	}
	for (i = 0; i < 9; i++)
	{
		fscanf(t, "%d ", &t4[i].id);
		fscanf(t, "%d ", &t4[i].salary);
		fscanf(t, "%d ", &t4[i].ben);
		fscanf(t, "%s ", t4[i].pos);
	}
	system("cls");
	printf("\nT1\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%d\t%s\t%d\n", t1[i].name, t1[i].lname, t1[i].ssn, t1[i].id, t1[i].pos, t1[i].salary);
	printf("\nT2\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%s\t%s\t%d\n", t2[i].name, t2[i].lname, t2[i].id, t2[i].city, t2[i].state, t2[i].b);
	printf("\nT3\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%d\t%d\t%s\n", t3[i].name, t3[i].lname, t3[i].id, t3[i].salary, t3[i].bon, t3[i].pos);
	printf("\nT4\n");
	for (i = 0; i < 9; i++)
		printf("%d\t%d\t%d\t%s\n", t4[i].id, t4[i].salary, t4[i].ben, t4[i].pos);
	printf("\n\n\n");

	return;
}
void load_query_file(FILE* q, QWR* qw)
{
	int QueryFlag = 1;
	int j, i = -1, c = 0;
	char b[100];
	char a[100];
	char*p;
	while (fgets(a, 100, q))
	{
		printf("%s", a);
		strcpy(b, a);
		p = strtok(a, " ");
		if (strcmp(p, "SELECT") == 0)
			i++;
		strcat(qs[i], b);

	}




	system("pause");
	return qs;

}

void load_query_files(FILE* q, QWR* qw)
{
	int QueryFlag = 1;
	int j, i = -1, c = 0;
	char b[100];
	char a[100];
	char*p;
	while (fgets(a, 100, q))
	{
		printf("%s", a);
		strcpy(b, a);
		p = strtok(a, " ");
		if (strcmp(p, "SELECT") == 0)
			i++;
		strcat(qs[i], b);

	}
	return qs;

}


int checkquerys()
{
	if (QueryFlag == 1 && TablesFlag == 1){
		return 1;
	}
	else{
		return 0;
	}
}

void checkselect()
{
	char seg[100];
	int  col = 0;
	functionFlag = 0;
	strcpy(functionName, "");
	strcpy(functionColumn, "");
	avg = 0;
	avg_counter = 0;
	sum = 0;
	max = -10000000;
	min = 10000000;

	if (strcmpi("EmployeeInformationTable", currentSegment[3]) == 0){
		currenttable = 1;
		EIEd.FirstName = 0;
		EIEd.LastName = 0;
		EIEd.SSN = 0;
		EIEd.ID = 0;
		EIEd.Position = 0;
		EIEd.Salary = 0;
		pch = strtok(currentSegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "FirstName") == 0){
					EIEd.FirstName = 1;
				}
				else if (strcmpi(seg, "LastName") == 0){
					EIEd.LastName = 1;
				}
				else if (strcmpi(seg, "SSN") == 0){
					EIEd.SSN = 1;
				}
				else if (strcmpi(seg, "ID") == 0){
					EIEd.ID = 1;
				}
				else if (strcmpi(seg, "Position") == 0){
					EIEd.Position = 1;
				}
				else if (strcmpi(seg, "Salary") == 0){
					EIEd.Salary = 1;
				}

				pch = strtok(NULL, ",");
			}
		}
		pch = strchr(currentSegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(currentSegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);

					if (strcmpi(functionColumn, "Salary") == 0) EIEd.Salary = 1;

					col++;
					pch = strtok(NULL, "()");
				}
			}
		}


	}
	else if (strcmpi("EmployeeAddressTable", currentSegment[3]) == 0){
		currenttable = 2;
		EAEd.FirstName = 0;
		EAEd.LastName = 0;
		EAEd.ID = 0;
		EAEd.City = 0;
		EAEd.State = 0;
		EAEd.Bldg = 0;

		pch = strtok(currentSegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "FirstName") == 0){
					EAEd.FirstName = 1;
				}
				else if (strcmpi(seg, "LastName") == 0){
					EAEd.LastName = 1;
				}
				else if (strcmpi(seg, "City") == 0){
					EAEd.City = 1;
				}
				else if (strcmpi(seg, "ID") == 0){
					EAEd.ID = 1;
				}
				else if (strcmpi(seg, "State") == 0){
					EAEd.State = 1;
				}
				else if (strcmpi(seg, "Bldg") == 0){
					EAEd.Bldg = 1;
				}

				pch = strtok(NULL, ",");
			}
		}

		pch = strchr(currentSegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(currentSegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);
					col++;
					pch = strtok(NULL, "()");
				}
			}
		}

	}
	else if (strcmpi("EmployeeBenefitstable", currentSegment[3]) == 0){
		currenttable = 3;
		EBEd.FirstName = 0;
		EBEd.LastName = 0;
		EBEd.ID = 0;
		EBEd.Salary = 0;
		EBEd.Bonus = 0;
		EBEd.Position = 0;

		pch = strtok(currentSegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "FirstName") == 0){
					EBEd.FirstName = 1;
				}
				else if (strcmpi(seg, "LastName") == 0){
					EBEd.LastName = 1;
				}
				else if (strcmpi(seg, "Salary") == 0){
					EBEd.Salary = 1;
				}
				else if (strcmpi(seg, "ID") == 0){
					EBEd.ID = 1;
				}
				else if (strcmpi(seg, "Bonus") == 0){
					EBEd.Bonus = 1;
				}
				else if (strcmpi(seg, "Position") == 0){
					EBEd.Position = 1;
				}

				pch = strtok(NULL, ",");
			}
		}

		pch = strchr(currentSegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(currentSegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);
					if (strcmpi(functionColumn, "Salary") == 0) EBEd.Salary = 1;
					if (strcmpi(functionColumn, "Bonus") == 0) EBEd.Bonus = 1;

					col++;
					pch = strtok(NULL, "()");
				}
			}
		}


	}
	else if (strcmpi("EMPLOYEEmployeeStatisticsTableATISTICSTABLE", currentSegment[3]) == 0){
		currenttable = 4;
		ESEd.EmployeeIDNo = 0;
		ESEd.Salary = 0;
		ESEd.Benefits = 0;
		ESEd.Position = 0;

		pch = strtok(currentSegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "EmployeeIDNo") == 0){
					ESEd.EmployeeIDNo = 1;
				}
				else if (strcmpi(seg, "Salary") == 0){
					ESEd.Salary = 1;
				}
				else if (strcmpi(seg, "Benefits") == 0){
					ESEd.Benefits = 1;
				}
				else if (strcmpi(seg, "Position") == 0){
					ESEd.Position = 1;
				}
				pch = strtok(NULL, ",");
			}
		}

		pch = strchr(currentSegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(currentSegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);
					if (strcmpi(functionColumn, "Salary") == 0) ESEd.Salary = 1;
					if (strcmpi(functionColumn, "Benefits") == 0) ESEd.Benefits = 1;

					col++;
					pch = strtok(NULL, "()");
				}
			}
		}


	}
}

void findcon()
{
	char condtion;
	char *ptr, *pch;
	int   col = 0;
	lookingFlag = 0;
	lookingCondition = 0;
	lookingCondition2 = 0;

	strcpy(lookingColumn, "");
	strcpy(lookingColumnValue, "");
	strcpy(lookingLink, "");
	strcpy(lookingColumn2, "");
	strcpy(lookingColumnValue2, "");
	lookingLikeChar = 0;


	if (strcmpi("WHERE", currentSegment[4]) == 0){
		lookingFlag = 1;

		if (strcmpi("LIKE", currentSegment[6]) == 0){
			lookingCondition = 6;
			strcpy(lookingColumn, currentSegment[5]);
			strcpy(lookingColumnValue, currentSegment[7]);

			col = 0;
			pch = strtok(lookingColumnValue, "'%");
			while (pch) {
				if (col == 0) strcpy(lookingColumnValue, pch);
				col++;
				pch = strtok(NULL, "'%");
			}

			lookingLikeChar = lookingColumnValue[0];

		}
		else{
			ptr = strchr(currentSegment[5], '>');
			if (ptr){
				if (*ptr == '>') {
					if (*(ptr + 1) == '='){
						lookingCondition = 1;
						pch = strtok(currentSegment[5], ">=");
						while (pch) {
							if (col == 0) strcpy(lookingColumn, pch);
							if (col == 1) strcpy(lookingColumnValue, pch);
							col++;
							pch = strtok(NULL, ">=");
							
						}

					}
					else{
						lookingCondition = 2;
						pch = strtok(currentSegment[5], ">");
						while (pch) {
							if (col == 0) strcpy(lookingColumn, pch);
							if (col == 1) strcpy(lookingColumnValue, pch);
							col++;
							pch = strtok(NULL, ">");
						}

					}
				}
			}

			ptr = strchr(currentSegment[5], '<');
			if (ptr){
				if (*ptr == '<') {
					if (*(ptr + 1) == '='){
						lookingCondition = 3;

						pch = strtok(currentSegment[5], "<=");
						while (pch) {
							if (col == 0) strcpy(lookingColumn, pch);
							if (col == 1) strcpy(lookingColumnValue, pch);

							col++;
							pch = strtok(NULL, "<=");
						}
					}
					else{
						lookingCondition = 4;

						pch = strtok(currentSegment[5], "<");
						while (pch) {
							if (col == 0) strcpy(lookingColumn, pch);
							if (col == 1) strcpy(lookingColumnValue, pch);

							col++;
							pch = strtok(NULL, "<");
						}
					}
				}
			}

			ptr = strchr(currentSegment[5], '=');
			if (ptr){
				if (*ptr == '=') {
					lookingCondition = 5;
					pch = strtok(currentSegment[5], "=");
					while (pch) {
						if (col == 0) strcpy(lookingColumn, pch);
						if (col == 1) strcpy(lookingColumnValue, pch);
						col++;
						pch = strtok(NULL, "=");
					}
					col = 0;
					pch = strtok(lookingColumnValue, "'");
					while (pch) {
						if (col == 0) strcpy(lookingColumnValue, pch);
						col++;
						pch = strtok(NULL, "'");
					}

				}
			}
			if (strcmpi(currentSegment[6], "OR") == 0 || strcmpi(currentSegment[6], "AND") == 0){
				if (strcmpi(currentSegment[6], "OR") == 0) strcpy(lookingLink, "OR"); // lookingLink to sotre OR
				if (strcmpi(currentSegment[6], "AND") == 0) strcpy(lookingLink, "AND"); // lookingLink to sotre AND
				col = 0;

				ptr = strchr(currentSegment[7], '>');
				if (ptr){
					if (*ptr == '>') {
						if (*(ptr + 1) == '='){
							lookingCondition2 = 1;
							pch = strtok(currentSegment[7], ">=");
							while (pch) {
								if (col == 0) strcpy(lookingColumn2, pch);
								if (col == 1) strcpy(lookingColumnValue2, pch);

								col++;
								pch = strtok(NULL, ">=");
							}

						}
						else{
							lookingCondition2 = 2;
							pch = strtok(currentSegment[7], ">");
							while (pch) {
								if (col == 0) strcpy(lookingColumn2, pch);
								if (col == 1) strcpy(lookingColumnValue2, pch);

								col++;
								pch = strtok(NULL, ">");
							}

						}
					}
				}

				ptr = strchr(currentSegment[7], '<');
				if (ptr){
					if (*ptr == '<') {
						if (*(ptr + 1) == '='){
							lookingCondition2 = 3;

							pch = strtok(currentSegment[7], "<=");
							while (pch) {
								if (col == 0) strcpy(lookingColumn2, pch);
								if (col == 1) strcpy(lookingColumnValue2, pch);

								col++;
								pch = strtok(NULL, "<=");
							}
						}
						else{
							lookingCondition2 = 4;

							pch = strtok(currentSegment[7], "<");
							while (pch) {
								if (col == 0) strcpy(lookingColumn2, pch);
								if (col == 1) strcpy(lookingColumnValue2, pch);

								col++;
								pch = strtok(NULL, "<");
							}
						}
					}
				}

				ptr = strchr(currentSegment[7], '=');
				if (ptr){
					if (*ptr == '=') {
						lookingCondition2 = 5;

						pch = strtok(currentSegment[7], "=");
						while (pch) {
							if (col == 0) strcpy(lookingColumn2, pch);
							if (col == 1) strcpy(lookingColumnValue2, pch);

							col++;
							pch = strtok(NULL, "=");
						}

						col = 0;
						pch = strtok(lookingColumnValue2, "'");
						while (pch) {
							if (col == 0) strcpy(lookingColumnValue2, pch);
							col++;
							pch = strtok(NULL, "'");
						}

					}
				}

			}

		}
	}
	else{
		lookingFlag = 0;
	}
}

int findrows(int row_check, EmployeeInformationTable* EmployeeInformationTable, EmployeeAddressTable* EmployeeAddressTable, EmployeeBenefitstable* EmployeeBenefitsTable, EmployeeStatisticsTable* EmployeeStatisticsTable) // to check if every row in table is valid or not according to select Query
{
	int WV = 0;
	int RV = 0;

	int WV2 = 0;
	int RV2 = 0;

	int condtion1 = 0;
	int condtion2 = 0;

	if (lookingFlag == 0){
		return 1;
	}
	else{
		if (currenttable == 1){
			if (strcmpi(lookingColumn, "FirstName") == 0){
				if (lookingCondition == 6){
					if (EmployeeInformationTable[row_check].name[0] == lookingLikeChar)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
				else{
					if (strcmpi(lookingColumnValue, EmployeeInformationTable[row_check].name) == 0)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
			}
			else if (strcmpi(lookingColumn, "LastName") == 0){
				if (strcmpi(lookingColumnValue, EmployeeInformationTable[row_check].lname) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "SSN") == 0){
				if (strcmpi(lookingColumnValue, EmployeeInformationTable[row_check].ssn) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "ID") == 0){
				if (strcmpi(lookingColumnValue, EmployeeInformationTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Position") == 0){
				if (strcmpi(lookingColumnValue, EmployeeInformationTable[row_check].pos) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Salary") == 0){

				RV = EmployeeInformationTable[row_check].salary;
				WV = atoi(lookingColumnValue);

				if (lookingCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 5){ // ==
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}

			if (strcmpi(lookingLink, "OR") == 0 || strcmpi(lookingLink, "AND") == 0){

				if (strcmpi(lookingColumn2, "FirstName") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeInformationTable[row_check].name) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "LastName") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeInformationTable[row_check].lname) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "SSN") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeInformationTable[row_check].ssn) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "ID") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeInformationTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "Position") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeInformationTable[row_check].pos) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "Salary") == 0){
					RV2 = EmployeeInformationTable[row_check].salary;
					WV2 = atoi(lookingColumnValue2);

					if (lookingCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}

				if (strcmpi(lookingLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}


		else if (currenttable == 2){
			if (strcmpi(lookingColumn, "FirstName") == 0){
				if (lookingCondition == 6){

					if (EmployeeAddressTable[row_check].name[0] == lookingLikeChar)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
				else{
					if (strcmpi(lookingColumnValue, EmployeeAddressTable[row_check].name) == 0)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
			}
			else if (strcmpi(lookingColumn, "LastName") == 0){
				if (strcmpi(lookingColumnValue, EmployeeAddressTable[row_check].lname) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "ID") == 0){
				if (strcmpi(lookingColumnValue, EmployeeAddressTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "City") == 0){
				if (strcmpi(lookingColumnValue, EmployeeAddressTable[row_check].city) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "State") == 0){
				if (strcmpi(lookingColumnValue, EmployeeAddressTable[row_check].state) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Bldg") == 0){
				if (strcmpi(lookingColumnValue, EmployeeAddressTable[row_check].b) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}


			if (strcmpi(lookingLink, "OR") == 0 || strcmpi(lookingLink, "AND") == 0){

				if (strcmpi(lookingColumn2, "FirstName") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeAddressTable[row_check].name) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "LastName") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeAddressTable[row_check].lname) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "City") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeAddressTable[row_check].city) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "ID") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeAddressTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "State") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeAddressTable[row_check].state) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "Bldg") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeAddressTable[row_check].b) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}

				if (strcmpi(lookingLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}


		if (currenttable == 3){
			if (strcmpi(lookingColumn, "FirstName") == 0){
				if (lookingCondition == 6){
					if (EmployeeBenefitsTable[row_check].name[0] == lookingLikeChar)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
				else{
					if (strcmpi(lookingColumnValue, EmployeeBenefitsTable[row_check].name) == 0)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
			}
			else if (strcmpi(lookingColumn, "LastName") == 0){
				if (strcmpi(lookingColumnValue, EmployeeBenefitsTable[row_check].lname) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "ID") == 0){
				if (strcmpi(lookingColumnValue, EmployeeBenefitsTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Position") == 0){
				if (strcmpi(lookingColumnValue, EmployeeBenefitsTable[row_check].pos) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Salary") == 0){


				RV = EmployeeBenefitsTable[row_check].salary;
				WV = atoi(lookingColumnValue);

				if (lookingCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}
			else if (strcmpi(lookingColumn, "Bonus") == 0){

				RV = EmployeeBenefitsTable[row_check].bon;
				WV = atoi(lookingColumnValue);

				if (lookingCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}



			if (strcmpi(lookingLink, "OR") == 0 || strcmpi(lookingLink, "AND") == 0){

				if (strcmpi(lookingColumn2, "FirstName") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeBenefitsTable[row_check].name) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "LastName") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeBenefitsTable[row_check].lname) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "ID") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeBenefitsTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "Position") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeBenefitsTable[row_check].pos) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "Salary") == 0){
					RV2 = EmployeeBenefitsTable[row_check].salary;
					WV2 = atoi(lookingColumnValue2);

					if (lookingCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}
				else if (strcmpi(lookingColumn2, "Bonus") == 0){
					RV2 = EmployeeBenefitsTable[row_check].bon;
					WV2 = atoi(lookingColumnValue2);

					if (lookingCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}

				if (strcmpi(lookingLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}

		if (currenttable == 4){
			if (strcmpi(lookingColumn, "EmployeeIDNo") == 0){
				if (strcmpi(lookingColumnValue, EmployeeStatisticsTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Position") == 0){
				if (strcmpi(lookingColumnValue, EmployeeStatisticsTable[row_check].pos) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(lookingColumn, "Salary") == 0){

				RV = EmployeeStatisticsTable[row_check].salary;
				WV = atoi(lookingColumnValue);

				if (lookingCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}
			else if (strcmpi(lookingColumn, "Benefits") == 0){

				RV = EmployeeStatisticsTable[row_check].ben;
				WV = atoi(lookingColumnValue);

				if (lookingCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (lookingCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}


			if (strcmpi(lookingLink, "OR") == 0 || strcmpi(lookingLink, "AND") == 0){

				if (strcmpi(lookingColumn2, "EmployeeIDNo") == 0){
					if (strcmpi(lookingColumnValue2, EmployeeStatisticsTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(lookingColumn2, "Position") == 0){

					if (strcmpi(lookingColumnValue2, EmployeeStatisticsTable[row_check].pos) == 0){
						condtion2 = 1;

					}
					else {
						condtion2 = 0;
					}
				}
				else if (strcmpi(lookingColumn2, "Salary") == 0){
					RV2 = EmployeeStatisticsTable[row_check].salary;
					WV2 = atoi(lookingColumnValue2);

					if (lookingCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}
				else if (strcmpi(lookingColumn2, "Benefits") == 0){
					RV2 = EmployeeStatisticsTable[row_check].ben;
					WV2 = lookingColumnValue2;

					if (lookingCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (lookingCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}

				if (strcmpi(lookingLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}
	}
}
