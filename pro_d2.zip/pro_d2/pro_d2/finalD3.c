#define _CRT_SECURE_NO_WARNINGS 
#if defined(_MSC_VER)
#if ndefn CRT SECURE_NO_DEPRECAT
#define CRT SECURE_NO_DEPRECAT (1)
#endif
#pragma warning(disable : 4996)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct
{
	char name[10];
	char lname[10];
	int ssn;
	int id;
	char pos[15];
	int salary;
}EIT;
typedef struct
{
	char name[10];
	char lname[10];
	int id;
	char city[10];
	char state[5];
	int b;
}EAT;
typedef struct
{
	char name[10];
	char lname[10];
	int id;
	int salary;
	int bon;
	char pos[15];

}EBT;
typedef struct
{
	int id;
	int salary;
	int ben;
	char pos[15];
}EST;
typedef struct
{
	char select[60];
	char from[60];
	char wher[60];

}QWR;

typedef struct EIE
{
	int FirstName;
	int LastName;
	int SSN;
	int ID;
	int Position;
	int Salary;
}EIE;
typedef struct EAE
{
	int FirstName;
	int LastName;
	int ID;
	int City;
	int State;
	int Bldg;
}EAE;
typedef struct EBE
{
	int FirstName;
	int LastName;
	int ID;
	int Salary;
	int Bonus;
	int Position;
}EBE;
typedef struct ESE
{
	int EmployeeIDNo;
	int Salary;
	int Benefits;
	int Position;
}ESE;



void ltf(EIT* t1, EAT* t2, EBT* t3, EST* t4, FILE* t);
void lqf(FILE* q, /*char qs[15][100],*/ QWR* qw);
void enableflags();
int chkQsTb();
void wherecon();
int checkwhere(int row_check);


int count_query = 0;
EIE EIEd;
EAE EAEd;
EBE EBEd;
ESE ESEd;

int selectn = 0;
int rows = 0;
char * Results; 
char * pch;
int  QueryFlag = 0;
int  TablesFlag = 0;

char ActiveQuery[999];
char ActiveQuerySegment[20][999];
int  ActiveQuerySegmentCounter = 0;

int ActiveTable = 0;

int  WhereFlag = 0;
int  WhereCondition = 0;

char WhereColumn[999];
char WhereColumnValue[999];
char WhereLink[999];

int WhereCondition2 = 0;
char WhereColumn2[999];
char WhereColumnValue2[999];
char WhereLikeChar;

int  functionFlag = 0;
char functionName[999];
char functionColumn[999];

long sum = 0;
float avg = 0;
int avg_counter;
long max = -10000000;
long min = 10000000;
char* qs[15][100];

int main()
{
	int i, r = 1, n, c, j;
	FILE* t;
	FILE* q;
	char qq[15][100];
	FILE* fp;
	EIT* t1;
	EAT* t2;
	EBT* t3;
	EST* t4;
	QWR* qw;
	t = fopen("appendixA.txt", "r");
	q = fopen("appendixB.txt", "r");
	if (t == NULL || q == NULL)
	{
		printf("files are not found\n\n\n");
		r = 0;

	}
	else
	{
		fclose(t);
		fclose(q);
		q = fopen("appendixB.txt", "r");
		while (fgets(qq, 100, q))
			selectn++;
		fclose(q);
		t1 = (EIT*)calloc(5, sizeof(EIT));
		t2 = (EAT*)calloc(5, sizeof(EAT));
		t3 = (EBT*)calloc(5, sizeof(EBT));
		t4 = (EST*)calloc(9, sizeof(EST));
		qw = (QWR*)calloc(selectn, sizeof(QWR));









		while (r)
		{
			do{
				system("cls");
				printf(" 1) Load Tiables file\n 2)Load Queries file \n 3)Execute and Display to Screen \n 4)Execute and Store to File \n 5)Exit \n");
				scanf("%d", &c);
				if (c > 5)
				{
					printf("Error/n/n");
					system("pause");
				}
			} while (c > 5);

			switch (c)
			{
			case 1:
			{
				t = fopen("appendixA.txt", "r");
				ltf(t1, t2, t3, t4, t);
				fclose(t);
				break;
			}
			case 2:
			{
				q = fopen("appendixB.txt", "r");
				lqf(q, qs, qw);
				fclose(q);
				break;
			}
			case 3:
			case 4:
			{
				fp = fopen("file.txt", "w");
				if (chkQsTb() == 1)
				{
					for (j = 0; j < selectn; j++){
						strcpy(ActiveQuery, qs[j]);
						printf("\n%s\n", ActiveQuery);
						if (c == 4)
							fprintf(fp, "\n%s\n", ActiveQuery);

						for (i = 0; i < 8; i++){
							strcpy(ActiveQuerySegment[i], "");
						}

						i = 0;
						pch = strtok(ActiveQuery, " ");
						while (pch != NULL)
						{
							strcpy(ActiveQuerySegment[i], pch);
							i++;
							pch = strtok(NULL, " ");
						}
						enableflags();
						wherecon();
						if (ActiveTable == 1){
							for (i = 0; i <= 4; i++)
							{
								if (checkwhere(i, t1, t2, t3, t4) == 1)
								{

									if (functionFlag == 1)
									{
										if (strcmpi(functionName, "SUM") == 0)
											sum += t1[i].salary;
										else if (strcmpi(functionName, "AVG") == 0)
										{
											sum += t1[i].salary;
											avg_counter++;
										}
										else if (strcmpi(functionName, "MAX") == 0)
										{
											if (max < t1[i].salary){
												max = t1[i].salary;
											}
										}
										else if (strcmpi(functionName, "MIN") == 0)
											if (min > t1[i].salary)
												min = t1[i].salary;
											else if (strcmpi(functionName, "COUNT") == 0)
												avg_counter++;

									}
									else
									{

										if (EIEd.FirstName == 1) printf("%s \t", t1[i].name);
										if (EIEd.LastName == 1) printf("%s \t", t1[i].lname);
										if (EIEd.SSN == 1) printf("%d \t", t1[i].ssn);
										if (EIEd.ID == 1) printf("%d \t", t1[i].id);
										if (EIEd.Position == 1) printf("%s \t", t1[i].pos);
										if (EIEd.Salary == 1) printf("%d \t", t1[i].salary);
										printf("\n");
										if (c == 4){
											if (EIEd.FirstName == 1) fprintf(fp, "%s \t", t1[i].name);
											if (EIEd.LastName == 1) fprintf(fp, "%s \t", t1[i].lname);
											if (EIEd.SSN == 1) fprintf(fp, "%d \t", t1[i].ssn);
											if (EIEd.ID == 1) fprintf(fp, "%d \t", t1[i].id);
											if (EIEd.Position == 1) fprintf(fp, "%s \t", t1[i].pos);
											if (EIEd.Salary == 1) fprintf(fp, "%d \t", t1[i].salary);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "SUM") == 0)
							{
								if (c == 4)
									fprintf(fp, "\n%d\n", sum);
								printf("\n%d\n", sum);
								sum = 0;
							}
							if (strcmpi(functionName, "AVG") == 0)
							{
								avg = sum / avg_counter;
								printf("\n%1.2f\n", avg);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg);
								sum = 0;
								avg_counter = 0;
							}
							if (strcmpi(functionName, "MAX") == 0)
							{
								printf("\n%d\n", max);
								if (c == 4)
									fprintf(fp, "\n%d\n", max);
								max = -10000000;
							}
							if (strcmpi(functionName, "MIN") == 0)
							{
								printf("\n%d\n", min);
								if (c == 4) fprintf(fp, "\n%d\n", min);
								min = 10000000;
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}
						if (ActiveTable == 2)
						{
							for (i = 0; i <= 4; i++)
							{
								if (checkwhere(i, t1, t2, t3, t4) == 1)
								{
									if (functionFlag == 1)
									{
										if (strcmpi(functionName, "COUNT") == 0)
											avg_counter++;

									}
									else
									{

										if (EAEd.FirstName == 1)
											printf("%s \t", t2[i].name);
										if (EAEd.LastName == 1)
											printf("%s \t", t2[i].lname);
										if (EAEd.ID == 1)
											printf("%d \t", t2[i].id);
										if (EAEd.City == 1)
											printf("%s \t", t2[i].city);
										if (EAEd.State == 1)
											printf("%s \t", t2[i].state);
										if (EAEd.Bldg == 1)
											printf("%d \t", t2[i].b);
										printf("\n");
										if (c == 4){
											if (EAEd.FirstName == 1)
												fprintf(fp, "%s \t", t2[i].name);
											if (EAEd.LastName == 1)
												fprintf(fp, "%s \t", t2[i].lname);
											if (EAEd.ID == 1)
												fprintf(fp, "%d \t", t2[i].id);
											if (EAEd.City == 1)
												fprintf(fp, "%s \t", t2[i].city);
											if (EAEd.State == 1)
												fprintf(fp, "%s \t", t2[i].state);
											if (EAEd.Bldg == 1)
												fprintf(fp, "%d \t", t2[i].b);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}
						if (ActiveTable == 3)
						{
							for (i = 0; i <= 4; i++)
							{
								if (checkwhere(i, t1, t2, t3, t4) == 1)
								{

									if (functionFlag == 1)
									{

										if (strcmpi(functionName, "SUM") == 0)
										{

											if (EBEd.Salary == 1)
												sum += t3[i].salary;
											if (EBEd.Bonus == 1)
												sum += t3[i].bon;

										}
										else if (strcmpi(functionName, "AVG") == 0)
										{
											if (EBEd.Salary == 1)
												sum += t3[i].salary;
											if (EBEd.Bonus == 1)
												sum += t3[i].bon;
											avg_counter++;
										}
										else if (strcmpi(functionName, "MAX") == 0)
										{
											if (EBEd.Salary == 1)
												if (max < t3[i].salary)
													max = t3[i].salary;
											if (EBEd.Bonus == 1)
												if (max < t3[i].bon)
													max = t3[i].bon;

										}
										else if (strcmpi(functionName, "MIN") == 0)
										{
											if (EBEd.Salary == 1)
												if (min > t3[i].salary)
													min = t3[i].salary;
											if (EBEd.Bonus == 1)
												if (min > t3[i].bon)
													min = t3[i].bon;
										}
										else if (strcmpi(functionName, "COUNT") == 0)
											avg_counter++;
									}
									else
									{
										if (EBEd.FirstName == 1)
											printf("%s \t", t3[i].name);
										if (EBEd.LastName == 1)
											printf("%s \t", t3[i].lname);
										if (EBEd.ID == 1)
											printf("%d \t", t3[i].id);
										if (EBEd.Salary == 1)
											printf("%d \t", t3[i].salary);
										if (EBEd.Bonus == 1)
											printf("%d \t", t3[i].bon);
										if (EBEd.Position == 1)
											printf("%s \t", t3[i].pos);

										printf("\n");
										if (c == 4){
											if (EBEd.FirstName == 1)
												fprintf(fp, "%s \t", t3[i].name);
											if (EBEd.LastName == 1)
												fprintf(fp, "%s \t", t3[i].lname);
											if (EBEd.ID == 1)
												fprintf(fp, "%d \t", t3[i].id);
											if (EBEd.Salary == 1)
												fprintf(fp, "%d \t", t3[i].salary);
											if (EBEd.Bonus == 1)
												fprintf(fp, "%d \t", t3[i].bon);
											if (EBEd.Position == 1)
												fprintf(fp, "%s \t", t3[i].pos);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "SUM") == 0)
							{
								if (c == 4)
									fprintf(fp, "\n%d\n", sum);
								printf("\n%d\n", sum);
								sum = 0;
							}
							if (strcmpi(functionName, "AVG") == 0)
							{
								avg = sum / avg_counter;
								printf("\n%1.2f\n", avg);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg);
								sum = 0;
								avg_counter = 0;
							}
							if (strcmpi(functionName, "MAX") == 0)
							{
								printf("\n%d\n", max);
								if (c == 4)
									fprintf(fp, "\n%d\n", max);
								max = -10000000;
							}
							if (strcmpi(functionName, "MIN") == 0)
							{
								printf("\n%d\n", min);
								if (c == 4)
									fprintf(fp, "\n%d\n", min);
								min = 10000000;
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}

						if (ActiveTable == 4)
						{
							for (i = 0; i <= 8; i++)
							{
								if (checkwhere(i, t1, t2, t3, t4) == 1)
								{

									if (functionFlag == 1)
									{

										if (strcmpi(functionName, "SUM") == 0)
										{

											if (ESEd.Salary == 1)
												sum += t4[i].salary;
											if (ESEd.Benefits == 1)
												sum += t4[i].ben;

										}
										else if (strcmpi(functionName, "AVG") == 0)
										{
											if (ESEd.Salary == 1)
												sum += t4[i].salary;
											if (ESEd.Benefits == 1)
												sum += t4[i].ben;
											avg_counter++;
										}
										else if (strcmpi(functionName, "MAX") == 0)
										{
											if (ESEd.Salary == 1)
												if (max < t4[i].salary)
													max = t4[i].salary;
											if (ESEd.Benefits == 1)
												if (max < t4[i].ben)
													max = t4[i].ben;

										}
										else if (strcmpi(functionName, "MIN") == 0)
										{
											if (ESEd.Salary == 1)
												if (min > t4[i].salary)
													min = t4[i].salary;
											if (ESEd.Benefits == 1)
												if (min > t4[i].ben)
													min = t4[i].ben;
										}
										else if (strcmpi(functionName, "COUNT") == 0)
											avg_counter++;
									}
									else
									{
										if (ESEd.EmployeeIDNo == 1)
											printf("%d \t", t4[i].id);
										if (ESEd.Salary == 1)
											printf("%d \t", t4[i].salary);
										if (ESEd.Benefits == 1)
											printf("%d \t", t4[i].ben);
										if (ESEd.Position == 1)
											printf("%s \t", t4[i].pos);
										printf("\n");
										if (c == 4)
										{
											if (ESEd.EmployeeIDNo == 1)
												fprintf(fp, "%d \t", t4[i].id);
											if (ESEd.Salary == 1)
												fprintf(fp, "%d \t", t4[i].salary);
											if (ESEd.Benefits == 1)
												fprintf(fp, "%d \t", t4[i].ben);
											if (ESEd.Position == 1)
												fprintf(fp, "%s \t", t4[i].pos);
											fprintf(fp, "\n");
										}
									}
								}
							}
							if (strcmpi(functionName, "SUM") == 0)
							{
								if (c == 4)
									fprintf(fp, "\n%d\n", sum);
								printf("\n%d\n", sum);
								sum = 0;
							}
							if (strcmpi(functionName, "AVG") == 0)
							{
								avg = sum / avg_counter;
								printf("\n%1.2f\n", avg);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg);
								sum = 0;
								avg_counter = 0;
							}
							if (strcmpi(functionName, "MAX") == 0)
							{
								printf("\n%d\n", max);
								if (c == c)
									fprintf(fp, "\n%d\n", max);
								max = -10000000;
							}
							if (strcmpi(functionName, "MIN") == 0)
							{
								printf("\n%d\n", min);
								if (c == 4)
									fprintf(fp, "\n%d\n", min);
								min = 10000000;
							}
							if (strcmpi(functionName, "COUNT") == 0)
							{
								printf("\n%d\n", avg_counter);
								if (c == 4)
									fprintf(fp, "\n%d\n", avg_counter);
								avg_counter = 0;
							}
						}

					}
				}
				else
				{
					printf("Please load table and query first!\n");
				}
				system("pause");
				fclose(fp);
				break;
			case 5:
			{
				system("cls");
				r = 0;
				printf("\n\n\n\n\n**************** Thank you for using our programme :) ****************\n\n\n\n\n");
				break;
			}
			system("pause");
			system("cls");
			}
			}
		}
		fclose(t);
		fclose(q);
		free(t1);
		free(t2);
		free(t3);
		free(t4);
		free(qw);
	}
	system("pause");
	return 0;
}

void ltf(EIT* t1, EAT* t2, EBT* t3, EST* t4, FILE* t)
{
	TablesFlag = 1;
	int i;
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t1[i].name);
		fscanf(t, "%s ", t1[i].lname);
		fscanf(t, "%d ", &t1[i].ssn);
		fscanf(t, "%d ", &t1[i].id);
		fscanf(t, "%s ", t1[i].pos);
		fscanf(t, "%d ", &t1[i].salary);
	}
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t2[i].name);
		fscanf(t, "%s ", t2[i].lname);
		fscanf(t, "%d ", &t2[i].id);
		fscanf(t, "%s ", t2[i].city);
		fscanf(t, "%s ", t2[i].state);
		fscanf(t, "%d ", &t2[i].b);
	}
	for (i = 0; i < 5; i++)
	{
		fscanf(t, "%s ", t3[i].name);
		fscanf(t, "%s ", t3[i].lname);
		fscanf(t, "%d ", &t3[i].id);
		fscanf(t, "%d ", &t3[i].salary);
		fscanf(t, "%d ", &t3[i].bon);
		fscanf(t, "%s ", t3[i].pos);
	}
	for (i = 0; i < 9; i++)
	{
		fscanf(t, "%d ", &t4[i].id);
		fscanf(t, "%d ", &t4[i].salary);
		fscanf(t, "%d ", &t4[i].ben);
		fscanf(t, "%s ", t4[i].pos);
	}
	system("cls");
	printf("\nT1\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%d\t%s\t%d\n", t1[i].name, t1[i].lname, t1[i].ssn, t1[i].id, t1[i].pos, t1[i].salary);
	printf("\nT2\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%s\t%s\t%d\n", t2[i].name, t2[i].lname, t2[i].id, t2[i].city, t2[i].state, t2[i].b);
	printf("\nT3\n");
	for (i = 0; i < 5; i++)
		printf("%s\t%s\t%d\t%d\t%d\t%s\n", t3[i].name, t3[i].lname, t3[i].id, t3[i].salary, t3[i].bon, t3[i].pos);
	printf("\nT4\n");
	for (i = 0; i < 9; i++)
		printf("%d\t%d\t%d\t%s\n", t4[i].id, t4[i].salary, t4[i].ben, t4[i].pos);
	printf("\n\n\n");

	system("pause");
	return;
}

void lqf(FILE* q, QWR* qw)
{
	QueryFlag = 1;
	int j, i = -1, c = 0;
	char b[100];
	char a[100];
	char*p;
	while (fgets(a, 100, q))
	{
		printf("%s", a);
		strcpy(b, a);
		p = strtok(a, " ");
		if (strcmp(p, "SELECT") == 0)
			i++;
		strcat(qs[i], b);

	}




	system("pause");
	return qs;

}



int chkQsTb()
{
	if (QueryFlag == 1 && TablesFlag == 1){
		return 1;
	}
	else{
		return 0;
	}
}

void enableflags()
{
	char seg[100];
	int  col = 0;
	functionFlag = 0;
	strcpy(functionName, "");
	strcpy(functionColumn, "");
	avg = 0;
	avg_counter = 0;
	sum = 0;
	max = -10000000;
	min = 10000000;

	if (strcmpi("EmployeeInformationTable", ActiveQuerySegment[3]) == 0){
		ActiveTable = 1;
		EIEd.FirstName = 0;
		EIEd.LastName = 0;
		EIEd.SSN = 0;
		EIEd.ID = 0;
		EIEd.Position = 0;
		EIEd.Salary = 0;
		pch = strtok(ActiveQuerySegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "FirstName") == 0){
					EIEd.FirstName = 1;
				}
				else if (strcmpi(seg, "LastName") == 0){
					EIEd.LastName = 1;
				}
				else if (strcmpi(seg, "SSN") == 0){
					EIEd.SSN = 1;
				}
				else if (strcmpi(seg, "ID") == 0){
					EIEd.ID = 1;
				}
				else if (strcmpi(seg, "Position") == 0){
					EIEd.Position = 1;
				}
				else if (strcmpi(seg, "Salary") == 0){
					EIEd.Salary = 1;
				}

				pch = strtok(NULL, ",");
			}
		}
		pch = strchr(ActiveQuerySegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(ActiveQuerySegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);

					if (strcmpi(functionColumn, "Salary") == 0) EIEd.Salary = 1;

					col++;
					pch = strtok(NULL, "()");
				}
			}
		}


	}
	else if (strcmpi("EmployeeAddressTable", ActiveQuerySegment[3]) == 0){
		ActiveTable = 2;
		EAEd.FirstName = 0;
		EAEd.LastName = 0;
		EAEd.ID = 0;
		EAEd.City = 0;
		EAEd.State = 0;
		EAEd.Bldg = 0;

		pch = strtok(ActiveQuerySegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "FirstName") == 0){
					EAEd.FirstName = 1;
				}
				else if (strcmpi(seg, "LastName") == 0){
					EAEd.LastName = 1;
				}
				else if (strcmpi(seg, "City") == 0){
					EAEd.City = 1;
				}
				else if (strcmpi(seg, "ID") == 0){
					EAEd.ID = 1;
				}
				else if (strcmpi(seg, "State") == 0){
					EAEd.State = 1;
				}
				else if (strcmpi(seg, "Bldg") == 0){
					EAEd.Bldg = 1;
				}

				pch = strtok(NULL, ",");
			}
		}

		pch = strchr(ActiveQuerySegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(ActiveQuerySegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);
					col++;
					pch = strtok(NULL, "()");
				}
			}
		}

	}
	else if (strcmpi("EmployeeBenefitstable", ActiveQuerySegment[3]) == 0){
		ActiveTable = 3;
		EBEd.FirstName = 0;
		EBEd.LastName = 0;
		EBEd.ID = 0;
		EBEd.Salary = 0;
		EBEd.Bonus = 0;
		EBEd.Position = 0;

		pch = strtok(ActiveQuerySegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "FirstName") == 0){
					EBEd.FirstName = 1;
				}
				else if (strcmpi(seg, "LastName") == 0){
					EBEd.LastName = 1;
				}
				else if (strcmpi(seg, "Salary") == 0){
					EBEd.Salary = 1;
				}
				else if (strcmpi(seg, "ID") == 0){
					EBEd.ID = 1;
				}
				else if (strcmpi(seg, "Bonus") == 0){
					EBEd.Bonus = 1;
				}
				else if (strcmpi(seg, "Position") == 0){
					EBEd.Position = 1;
				}

				pch = strtok(NULL, ",");
			}
		}

		pch = strchr(ActiveQuerySegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(ActiveQuerySegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);
					if (strcmpi(functionColumn, "Salary") == 0) EBEd.Salary = 1;
					if (strcmpi(functionColumn, "Bonus") == 0) EBEd.Bonus = 1;

					col++;
					pch = strtok(NULL, "()");
				}
			}
		}


	}
	else if (strcmpi("EMPLOYEESTATISTICSTABLE", ActiveQuerySegment[3]) == 0){
		ActiveTable = 4;
		ESEd.EmployeeIDNo = 0;
		ESEd.Salary = 0;
		ESEd.Benefits = 0;
		ESEd.Position = 0;

		pch = strtok(ActiveQuerySegment[1], ",");
		if (pch){
			while (pch != NULL)
			{
				strcpy(seg, pch);
				if (strcmpi(seg, "EmployeeIDNo") == 0){
					ESEd.EmployeeIDNo = 1;
				}
				else if (strcmpi(seg, "Salary") == 0){
					ESEd.Salary = 1;
				}
				else if (strcmpi(seg, "Benefits") == 0){
					ESEd.Benefits = 1;
				}
				else if (strcmpi(seg, "Position") == 0){
					ESEd.Position = 1;
				}
				pch = strtok(NULL, ",");
			}
		}

		pch = strchr(ActiveQuerySegment[1], '(');
		if (pch){
			functionFlag = 1;
			pch = strtok(ActiveQuerySegment[1], "()");
			col = 0;
			if (pch){
				while (pch != NULL)
				{
					if (col == 0) strcpy(functionName, pch);
					else if (col == 1) strcpy(functionColumn, pch);
					if (strcmpi(functionColumn, "Salary") == 0) ESEd.Salary = 1;
					if (strcmpi(functionColumn, "Benefits") == 0) ESEd.Benefits = 1;

					col++;
					pch = strtok(NULL, "()");
				}
			}
		}


	}
	else{
		printf("Error In Getting Query Or Table");
	}
}

void wherecon()
{
	char condtion;
	char *ptr, *pch;
	int   col = 0;
	WhereFlag = 0;
	WhereCondition = 0;
	WhereCondition2 = 0;

	strcpy(WhereColumn, "");
	strcpy(WhereColumnValue, "");
	strcpy(WhereLink, "");
	strcpy(WhereColumn2, "");
	strcpy(WhereColumnValue2, "");
	WhereLikeChar = 0;


	if (strcmpi("WHERE", ActiveQuerySegment[4]) == 0){
		WhereFlag = 1;

		if (strcmpi("LIKE", ActiveQuerySegment[6]) == 0){
			WhereCondition = 6;
			strcpy(WhereColumn, ActiveQuerySegment[5]);
			strcpy(WhereColumnValue, ActiveQuerySegment[7]);

			col = 0;
			pch = strtok(WhereColumnValue, "'%");
			while (pch) {
				if (col == 0) strcpy(WhereColumnValue, pch);
				col++;
				pch = strtok(NULL, "'%");
			}

			WhereLikeChar = WhereColumnValue[0];

		}
		else{
			ptr = strchr(ActiveQuerySegment[5], '>');
			if (ptr){
				if (*ptr == '>') {
					if (*(ptr + 1) == '='){
						WhereCondition = 1;
						pch = strtok(ActiveQuerySegment[5], ">=");
						while (pch) {
							if (col == 0) strcpy(WhereColumn, pch);
							if (col == 1) strcpy(WhereColumnValue, pch);
							col++;
							pch = strtok(NULL, ">=");
							
						}

					}
					else{
						WhereCondition = 2;
						pch = strtok(ActiveQuerySegment[5], ">");
						while (pch) {
							if (col == 0) strcpy(WhereColumn, pch);
							if (col == 1) strcpy(WhereColumnValue, pch);
							col++;
							pch = strtok(NULL, ">");
						}

					}
				}
			}

			ptr = strchr(ActiveQuerySegment[5], '<');
			if (ptr){
				if (*ptr == '<') {
					if (*(ptr + 1) == '='){
						WhereCondition = 3;

						pch = strtok(ActiveQuerySegment[5], "<=");
						while (pch) {
							if (col == 0) strcpy(WhereColumn, pch);
							if (col == 1) strcpy(WhereColumnValue, pch);

							col++;
							pch = strtok(NULL, "<=");
						}
					}
					else{
						WhereCondition = 4;

						pch = strtok(ActiveQuerySegment[5], "<");
						while (pch) {
							if (col == 0) strcpy(WhereColumn, pch);
							if (col == 1) strcpy(WhereColumnValue, pch);

							col++;
							pch = strtok(NULL, "<");
						}
					}
				}
			}

			ptr = strchr(ActiveQuerySegment[5], '=');
			if (ptr){
				if (*ptr == '=') {
					WhereCondition = 5;
					pch = strtok(ActiveQuerySegment[5], "=");
					while (pch) {
						if (col == 0) strcpy(WhereColumn, pch);
						if (col == 1) strcpy(WhereColumnValue, pch);
						col++;
						pch = strtok(NULL, "=");
					}
					col = 0;
					pch = strtok(WhereColumnValue, "'");
					while (pch) {
						if (col == 0) strcpy(WhereColumnValue, pch);
						col++;
						pch = strtok(NULL, "'");
					}

				}
			}
			if (strcmpi(ActiveQuerySegment[6], "OR") == 0 || strcmpi(ActiveQuerySegment[6], "AND") == 0){
				if (strcmpi(ActiveQuerySegment[6], "OR") == 0) strcpy(WhereLink, "OR"); // WhereLink to sotre OR
				if (strcmpi(ActiveQuerySegment[6], "AND") == 0) strcpy(WhereLink, "AND"); // WhereLink to sotre AND
				col = 0;

				ptr = strchr(ActiveQuerySegment[7], '>');
				if (ptr){
					if (*ptr == '>') {
						if (*(ptr + 1) == '='){
							WhereCondition2 = 1;
							pch = strtok(ActiveQuerySegment[7], ">=");
							while (pch) {
								if (col == 0) strcpy(WhereColumn2, pch);
								if (col == 1) strcpy(WhereColumnValue2, pch);

								col++;
								pch = strtok(NULL, ">=");
							}

						}
						else{
							WhereCondition2 = 2;
							pch = strtok(ActiveQuerySegment[7], ">");
							while (pch) {
								if (col == 0) strcpy(WhereColumn2, pch);
								if (col == 1) strcpy(WhereColumnValue2, pch);

								col++;
								pch = strtok(NULL, ">");
							}

						}
					}
				}

				ptr = strchr(ActiveQuerySegment[7], '<');
				if (ptr){
					if (*ptr == '<') {
						if (*(ptr + 1) == '='){
							WhereCondition2 = 3;

							pch = strtok(ActiveQuerySegment[7], "<=");
							while (pch) {
								if (col == 0) strcpy(WhereColumn2, pch);
								if (col == 1) strcpy(WhereColumnValue2, pch);

								col++;
								pch = strtok(NULL, "<=");
							}
						}
						else{
							WhereCondition2 = 4;

							pch = strtok(ActiveQuerySegment[7], "<");
							while (pch) {
								if (col == 0) strcpy(WhereColumn2, pch);
								if (col == 1) strcpy(WhereColumnValue2, pch);

								col++;
								pch = strtok(NULL, "<");
							}
						}
					}
				}

				ptr = strchr(ActiveQuerySegment[7], '=');
				if (ptr){
					if (*ptr == '=') {
						WhereCondition2 = 5;

						pch = strtok(ActiveQuerySegment[7], "=");
						while (pch) {
							if (col == 0) strcpy(WhereColumn2, pch);
							if (col == 1) strcpy(WhereColumnValue2, pch);

							col++;
							pch = strtok(NULL, "=");
						}

						col = 0;
						pch = strtok(WhereColumnValue2, "'");
						while (pch) {
							if (col == 0) strcpy(WhereColumnValue2, pch);
							col++;
							pch = strtok(NULL, "'");
						}

					}
				}

			}

		}
	}
	else{
		WhereFlag = 0;
	}
}

int checkwhere(int row_check, EIT* EmployeeInformationTable, EAT* EmployeeAddressTable, EBT* EmployeeBenefitsTable, EST* EmployeeStatisticsTable) // to check if every row in table is valid or not according to select Query
{
	int WV = 0;
	int RV = 0;

	int WV2 = 0;
	int RV2 = 0;

	int condtion1 = 0;
	int condtion2 = 0;

	if (WhereFlag == 0){
		return 1;
	}
	else{
		if (ActiveTable == 1){
			if (strcmpi(WhereColumn, "FirstName") == 0){
				if (WhereCondition == 6){
					if (EmployeeInformationTable[row_check].name[0] == WhereLikeChar)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
				else{
					if (strcmpi(WhereColumnValue, EmployeeInformationTable[row_check].name) == 0)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
			}
			else if (strcmpi(WhereColumn, "LastName") == 0){
				if (strcmpi(WhereColumnValue, EmployeeInformationTable[row_check].lname) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "SSN") == 0){
				if (strcmpi(WhereColumnValue, EmployeeInformationTable[row_check].ssn) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "ID") == 0){
				if (strcmpi(WhereColumnValue, EmployeeInformationTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Position") == 0){
				if (strcmpi(WhereColumnValue, EmployeeInformationTable[row_check].pos) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Salary") == 0){

				RV = EmployeeInformationTable[row_check].salary;
				WV = atoi(WhereColumnValue);

				if (WhereCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 5){ // ==
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}

			if (strcmpi(WhereLink, "OR") == 0 || strcmpi(WhereLink, "AND") == 0){

				if (strcmpi(WhereColumn2, "FirstName") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeInformationTable[row_check].name) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "LastName") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeInformationTable[row_check].lname) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "SSN") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeInformationTable[row_check].ssn) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "ID") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeInformationTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "Position") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeInformationTable[row_check].pos) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "Salary") == 0){
					RV2 = EmployeeInformationTable[row_check].salary;
					WV2 = atoi(WhereColumnValue2);

					if (WhereCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}

				if (strcmpi(WhereLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}


		else if (ActiveTable == 2){
			if (strcmpi(WhereColumn, "FirstName") == 0){
				if (WhereCondition == 6){

					if (EmployeeAddressTable[row_check].name[0] == WhereLikeChar)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
				else{
					if (strcmpi(WhereColumnValue, EmployeeAddressTable[row_check].name) == 0)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
			}
			else if (strcmpi(WhereColumn, "LastName") == 0){
				if (strcmpi(WhereColumnValue, EmployeeAddressTable[row_check].lname) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "ID") == 0){
				if (strcmpi(WhereColumnValue, EmployeeAddressTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "City") == 0){
				if (strcmpi(WhereColumnValue, EmployeeAddressTable[row_check].city) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "State") == 0){
				if (strcmpi(WhereColumnValue, EmployeeAddressTable[row_check].state) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Bldg") == 0){
				if (strcmpi(WhereColumnValue, EmployeeAddressTable[row_check].b) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}


			if (strcmpi(WhereLink, "OR") == 0 || strcmpi(WhereLink, "AND") == 0){

				if (strcmpi(WhereColumn2, "FirstName") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeAddressTable[row_check].name) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "LastName") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeAddressTable[row_check].lname) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "City") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeAddressTable[row_check].city) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "ID") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeAddressTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "State") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeAddressTable[row_check].state) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "Bldg") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeAddressTable[row_check].b) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}

				if (strcmpi(WhereLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}


		if (ActiveTable == 3){
			if (strcmpi(WhereColumn, "FirstName") == 0){
				if (WhereCondition == 6){
					if (EmployeeBenefitsTable[row_check].name[0] == WhereLikeChar)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
				else{
					if (strcmpi(WhereColumnValue, EmployeeBenefitsTable[row_check].name) == 0)
						condtion1 = 1;
					else
						condtion1 = 0;
				}
			}
			else if (strcmpi(WhereColumn, "LastName") == 0){
				if (strcmpi(WhereColumnValue, EmployeeBenefitsTable[row_check].lname) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "ID") == 0){
				if (strcmpi(WhereColumnValue, EmployeeBenefitsTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Position") == 0){
				if (strcmpi(WhereColumnValue, EmployeeBenefitsTable[row_check].pos) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Salary") == 0){


				RV = EmployeeBenefitsTable[row_check].salary;
				WV = atoi(WhereColumnValue);

				if (WhereCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}
			else if (strcmpi(WhereColumn, "Bonus") == 0){

				RV = EmployeeBenefitsTable[row_check].bon;
				WV = atoi(WhereColumnValue);

				if (WhereCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}



			if (strcmpi(WhereLink, "OR") == 0 || strcmpi(WhereLink, "AND") == 0){

				if (strcmpi(WhereColumn2, "FirstName") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeBenefitsTable[row_check].name) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "LastName") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeBenefitsTable[row_check].lname) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "ID") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeBenefitsTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "Position") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeBenefitsTable[row_check].pos) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "Salary") == 0){
					RV2 = EmployeeBenefitsTable[row_check].salary;
					WV2 = atoi(WhereColumnValue2);

					if (WhereCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}
				else if (strcmpi(WhereColumn2, "Bonus") == 0){
					RV2 = EmployeeBenefitsTable[row_check].bon;
					WV2 = atoi(WhereColumnValue2);

					if (WhereCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}

				if (strcmpi(WhereLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}

		if (ActiveTable == 4){
			if (strcmpi(WhereColumn, "EmployeeIDNo") == 0){
				if (strcmpi(WhereColumnValue, EmployeeStatisticsTable[row_check].id) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Position") == 0){
				if (strcmpi(WhereColumnValue, EmployeeStatisticsTable[row_check].pos) == 0)
					condtion1 = 1;
				else
					condtion1 = 0;
			}
			else if (strcmpi(WhereColumn, "Salary") == 0){

				RV = EmployeeStatisticsTable[row_check].salary;
				WV = atoi(WhereColumnValue);

				if (WhereCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}
			else if (strcmpi(WhereColumn, "Benefits") == 0){

				RV = EmployeeStatisticsTable[row_check].ben;
				WV = atoi(WhereColumnValue);

				if (WhereCondition == 1){
					if (RV >= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 2){
					if (RV > WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 3){
					if (RV <= WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 4){
					if (RV < WV) condtion1 = 1;
					else condtion1 = 0;
				}
				else if (WhereCondition == 5){
					if (RV == WV) condtion1 = 1;
					else condtion1 = 0;
				}
			}


			if (strcmpi(WhereLink, "OR") == 0 || strcmpi(WhereLink, "AND") == 0){

				if (strcmpi(WhereColumn2, "EmployeeIDNo") == 0){
					if (strcmpi(WhereColumnValue2, EmployeeStatisticsTable[row_check].id) == 0)
						condtion2 = 1;
					else
						condtion2 = 0;
				}
				else if (strcmpi(WhereColumn2, "Position") == 0){

					if (strcmpi(WhereColumnValue2, EmployeeStatisticsTable[row_check].pos) == 0){
						condtion2 = 1;

					}
					else {
						condtion2 = 0;
					}
				}
				else if (strcmpi(WhereColumn2, "Salary") == 0){
					RV2 = EmployeeStatisticsTable[row_check].salary;
					WV2 = atoi(WhereColumnValue2);

					if (WhereCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}
				else if (strcmpi(WhereColumn2, "Benefits") == 0){
					RV2 = EmployeeStatisticsTable[row_check].ben;
					WV2 = WhereColumnValue2;

					if (WhereCondition2 == 1){
						if (RV2 >= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 2){
						if (RV2 > WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 3){
						if (RV2 <= WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 4){
						if (RV2 < WV2) condtion2 = 1;
						else condtion2 = 0;
					}
					else if (WhereCondition2 == 5){
						if (RV2 == WV2) condtion2 = 1;
						else condtion2 = 0;
					}
				}

				if (strcmpi(WhereLink, "OR") == 0)
					return condtion1 || condtion2;
				else
					return condtion1 && condtion2;
			}
			else{
				return condtion1;
			}

		}
	}

}





















































































































































































































































































